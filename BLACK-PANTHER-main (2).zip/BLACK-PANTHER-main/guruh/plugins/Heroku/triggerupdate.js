import axios from 'axios';
import ownerMiddleware from '../../utils/botUtil/Ownermiddleware.js';

import { herokuAppName as HEROKU_APP_NAME, getHerokuApiKey } from '../../config/settings.js';
const HEROKU_API_KEY = getHerokuApiKey();

export default async (context) => {
    const { client, m } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });

    const formatStylishReply = (message) => {
        return (
            `` +
            `│ ${message}\n` +
            `╰───────────────
> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 𝐆𝐔𝐑𝐔𝐓𝐄𝐂𝐇\n` +
            `xD`
        );
    };

    await ownerMiddleware(context, async () => {
        await client.sendMessage(m.chat, { react: { text: '🚀', key: m.reactKey } });

        try {
            if (!HEROKU_API_KEY || !HEROKU_APP_NAME) {
                await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });
                return await client.sendMessage(
                    m.chat,
                    {
                        text: formatStylishReply(
                            "⚠️ Seriously? You forgot to set *HEROKU_API_KEY* or *HEROKU_APP_NAME*.\n" +
                            "Fix your setup before crying for updates. 🙄"
                        ) }
                );
            }

            await client.sendMessage(
                m.chat,
                {
                    text: formatStylishReply(
                        "🔄 Fine… triggering update.\n" +
                        "Don’t complain if the bot restarts in your face. 😒"
                    ) }
            );

            await axios.post(
                `https://api.heroku.com/apps/${HEROKU_APP_NAME}/builds`,
                {
                    source_blob: {
                        url: "https://github.com/koyoteh/BLACK-PANTHER/tarball/main" } },
                {
                    headers: {
                        Authorization: `Bearer ${HEROKU_API_KEY}`,
                        Accept: "application/vnd.heroku+json; version=3",
                        "Content-Type": "application/json" } }
            );

            return await client.sendMessage(
                m.chat,
                {
                    text: formatStylishReply(
                        "🚀 Update triggered.\n" +
                        "Sit tight while BLACK-PANTHER-MD resurrects with fresh upgrades. 🔥"
                    ) }
            );

        } catch (error) {
            const errorMessage = error.response?.data?.message || error.message;

            let msg;

            if (errorMessage.includes("API key")) {
                msg =
                    "❌ Your Heroku API key is trash.\n" +
                    "Fix *HEROKU_API_KEY* before crying here.";
            } else if (errorMessage.includes("not found")) {
                msg =
                    "❌ Heroku app not found.\n" +
                    "Are you sure *HEROKU_APP_NAME* is correct, genius?";
            } else {
                msg = `❌ Update failed:\n${errorMessage}\nTry again without panicking.`;
            }

            await client.sendMessage(
                m.chat,
                { text: formatStylishReply(msg) }
            );
        }
    });
};